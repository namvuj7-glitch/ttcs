<hr>
<footer>
  <p>© 2025 Web Truyện PHP Local</p>
</footer>
